Drunken Parrot Flat UI PSD
=======

Drunken Parrot Flat UI PSD is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/) and MIT License - http://opensource.org/licenses/mit-license.html.

## Links:

+ [Hoarrd.com](http://hoarrd.com)
+ [Components & Style Guide: Free Version](http://hoarrd.github.io/drunken-parrot-flat-ui/)
